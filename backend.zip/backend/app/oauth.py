from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import json
import secrets
from typing import Optional
from urllib.parse import urlencode

import httpx

from .config import Settings
from .models import AuthStartResponse, AuthStatusResponse, Platform, PlatformAuthStatus
from .signing import md5_platform_sign
from .token_store import TokenStore


@dataclass
class PendingAuthorization:
    platform: Platform
    client_session_id: str
    expires_at: datetime


class OAuthService:
    def __init__(self, settings: Settings, client: httpx.AsyncClient, token_store: TokenStore):
        self.settings = settings
        self.client = client
        self.token_store = token_store
        self.pending: dict[str, PendingAuthorization] = {}
        self.demo_authorized: dict[str, set[Platform]] = {}

    def start(self, platform: Platform, client_session_id: str) -> AuthStartResponse:
        if platform == Platform.DOUYIN:
            raise RuntimeError("抖音精选联盟需企业主体完成应用上架后，由服务端配置达人或抖客授权令牌")
        state = secrets.token_urlsafe(32)
        self.pending[state] = PendingAuthorization(
            platform=platform,
            client_session_id=client_session_id,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=10),
        )
        if not self._is_live_configured(platform):
            if not self.settings.allow_demo_fallback:
                raise RuntimeError(f"{platform.value} OAuth 尚未配置")
            self.demo_authorized.setdefault(client_session_id, set()).add(platform)
            query = urlencode({"platform": platform.value, "success": "true", "demo": "true"})
            return AuthStartResponse(
                platform=platform,
                authorizationUrl=f"{self.settings.app_return_url}?{query}",
                demo=True,
            )

        redirect_uri = self._callback_url(platform)
        params = {
            "client_id": self._client_id(platform),
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "state": state,
        }
        scope = self._scope(platform)
        if scope:
            params["scope"] = scope
        if platform == Platform.TAOBAO:
            params["view"] = "web"
        return AuthStartResponse(
            platform=platform,
            authorizationUrl=f"{self._auth_url(platform)}?{urlencode(params)}",
        )

    async def complete(self, platform: Platform, state: str, code: str) -> str:
        if platform == Platform.DOUYIN:
            raise RuntimeError("抖音精选联盟授权码需按开放平台上架后的服务使用地址接收")
        pending = self.pending.pop(state, None)
        if pending is None or pending.platform != platform:
            raise RuntimeError("授权状态无效或已过期")
        if pending.expires_at < datetime.now(timezone.utc):
            raise RuntimeError("授权状态已过期")

        token = await self._exchange_token(platform, code)
        self.token_store.save(
            client_session_id=pending.client_session_id,
            platform=platform,
            access_token=token["access_token"],
            refresh_token=token.get("refresh_token", ""),
            expires_at=token.get("expires_at"),
        )
        query = urlencode({"platform": platform.value, "success": "true"})
        return f"{self.settings.app_return_url}?{query}"

    def status(self, client_session_id: str) -> AuthStatusResponse:
        demo = self.demo_authorized.get(client_session_id, set())
        return AuthStatusResponse(
            platforms=[
                PlatformAuthStatus(
                    platform=platform,
                    authorized=platform in demo or self.token_store.is_authorized(client_session_id, platform),
                )
                for platform in Platform
            ]
        )

    def revoke(self, client_session_id: str, platform: Platform) -> None:
        self.demo_authorized.get(client_session_id, set()).discard(platform)
        self.token_store.revoke(client_session_id, platform)

    async def _exchange_token(self, platform: Platform, code: str) -> dict[str, str]:
        redirect_uri = self._callback_url(platform)
        if platform == Platform.PDD:
            params = {
                "type": "pdd.pop.auth.token.create",
                "client_id": self.settings.pdd_client_id,
                "timestamp": int(datetime.now().timestamp()),
                "data_type": "JSON",
                "code": code,
            }
            params["sign"] = md5_platform_sign(params, self.settings.pdd_client_secret)
            response = await self.client.post(self.settings.pdd_gateway, data=params)
            response.raise_for_status()
            payload = response.json().get("pop_auth_token_create_response", {})
        else:
            response = await self.client.post(
                self._token_url(platform),
                data={
                    "grant_type": "authorization_code",
                    "client_id": self._client_id(platform),
                    "client_secret": self._client_secret(platform),
                    "code": code,
                    "redirect_uri": redirect_uri,
                },
            )
            response.raise_for_status()
            payload = response.json()
            if isinstance(payload, str):
                payload = json.loads(payload)

        access_token = payload.get("access_token")
        if not access_token:
            raise RuntimeError(f"{platform.value} 未返回 access_token")
        expires_at: Optional[str] = None
        expires_in = payload.get("expires_in")
        if expires_in:
            expires_at = (
                datetime.now(timezone.utc) + timedelta(seconds=int(expires_in))
            ).isoformat()
        return {
            "access_token": str(access_token),
            "refresh_token": str(payload.get("refresh_token") or ""),
            "expires_at": expires_at or "",
        }

    def _is_live_configured(self, platform: Platform) -> bool:
        common = bool(self.settings.public_base_url and self.settings.token_encryption_key)
        if platform == Platform.TAOBAO:
            return common and all((self.settings.taobao_app_key, self.settings.taobao_app_secret,
                                   self.settings.taobao_auth_url, self.settings.taobao_token_url))
        if platform == Platform.JD:
            return common and all((self.settings.jd_app_key, self.settings.jd_app_secret,
                                   self.settings.jd_auth_url, self.settings.jd_token_url))
        return common and all((self.settings.pdd_client_id, self.settings.pdd_client_secret,
                               self.settings.pdd_auth_url, self.settings.pdd_gateway))

    def _callback_url(self, platform: Platform) -> str:
        return f"{self.settings.public_base_url.rstrip('/')}/api/v1/auth/callback/{platform.value}"

    def _client_id(self, platform: Platform) -> str:
        return {
            Platform.TAOBAO: self.settings.taobao_app_key,
            Platform.JD: self.settings.jd_app_key,
            Platform.PDD: self.settings.pdd_client_id,
        }[platform]

    def _client_secret(self, platform: Platform) -> str:
        return {
            Platform.TAOBAO: self.settings.taobao_app_secret,
            Platform.JD: self.settings.jd_app_secret,
            Platform.PDD: self.settings.pdd_client_secret,
        }[platform]

    def _auth_url(self, platform: Platform) -> str:
        return {
            Platform.TAOBAO: self.settings.taobao_auth_url,
            Platform.JD: self.settings.jd_auth_url,
            Platform.PDD: self.settings.pdd_auth_url,
        }[platform]

    def _token_url(self, platform: Platform) -> str:
        return {
            Platform.TAOBAO: self.settings.taobao_token_url,
            Platform.JD: self.settings.jd_token_url,
        }[platform]

    def _scope(self, platform: Platform) -> str:
        return {
            Platform.TAOBAO: self.settings.taobao_oauth_scope,
            Platform.JD: self.settings.jd_oauth_scope,
            Platform.PDD: self.settings.pdd_oauth_scope,
        }[platform]
