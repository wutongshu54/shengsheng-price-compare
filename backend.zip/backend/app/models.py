from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class Platform(str, Enum):
    TAOBAO = "TAOBAO"
    JD = "JD"
    PDD = "PDD"


class ShopType(str, Enum):
    FLAGSHIP = "FLAGSHIP"
    OFFICIAL = "OFFICIAL"
    POP = "POP"


class SortOption(str, Enum):
    recommended = "recommended"
    price_lowest = "price_lowest"
    rating_first = "rating_first"


class SearchRequest(BaseModel):
    keyword: str = Field(min_length=1, max_length=120)
    sort: SortOption = SortOption.recommended
    page: int = Field(default=1, ge=1, le=100)
    pageSize: int = Field(default=30, ge=1, le=100)
    clientSessionId: Optional[str] = Field(default=None, min_length=8, max_length=128)


class Offer(BaseModel):
    id: str
    platform: Platform
    title: str
    specification: str = ""
    price: float
    originalPrice: float
    coupon: float = 0
    finalPrice: float
    rating: float = 0
    reviewCount: int = 0
    sales: int = 0
    shopType: ShopType = ShopType.POP
    matchConfidence: float = 0.8
    productUrl: str = ""
    lowestPrice: bool = False
    bestValue: bool = False


class SearchResponse(BaseModel):
    requestId: str
    keyword: str
    recognizedKeyword: Optional[str] = None
    currency: str = "CNY"
    priceUpdatedAt: str
    mode: str
    platformErrors: List[str] = Field(default_factory=list)
    offers: List[Offer]


class RecognitionResponse(BaseModel):
    keyword: str
    confidence: float


class AuthStartRequest(BaseModel):
    clientSessionId: str = Field(min_length=8, max_length=128)


class AuthStartResponse(BaseModel):
    platform: Platform
    authorizationUrl: str
    demo: bool = False


class PlatformAuthStatus(BaseModel):
    platform: Platform
    authorized: bool


class AuthStatusResponse(BaseModel):
    platforms: List[PlatformAuthStatus]
