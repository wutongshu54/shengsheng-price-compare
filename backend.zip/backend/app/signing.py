import hashlib
import hmac
from typing import Mapping


def md5_platform_sign(params: Mapping[str, object], secret: str) -> str:
    """淘宝、京东和拼多多常用的 MD5 参数签名形式。"""
    body = "".join(
        f"{key}{value}"
        for key, value in sorted(params.items())
        if key != "sign" and value is not None and str(value) != ""
    )
    return hashlib.md5(f"{secret}{body}{secret}".encode("utf-8")).hexdigest().upper()


def douyin_hmac_sha256_sign(
    *,
    app_key: str,
    app_secret: str,
    method: str,
    param_json: str,
    timestamp: str,
    version: str = "2",
) -> str:
    parameter_pattern = (
        f"app_key{app_key}"
        f"method{method}"
        f"param_json{param_json}"
        f"timestamp{timestamp}"
        f"v{version}"
    )
    sign_pattern = f"{app_secret}{parameter_pattern}{app_secret}"
    return hmac.new(
        app_secret.encode("utf-8"),
        sign_pattern.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
