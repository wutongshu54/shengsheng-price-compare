import hashlib
from typing import Mapping


def md5_platform_sign(params: Mapping[str, object], secret: str) -> str:
    """淘宝、京东和拼多多常用的 MD5 参数签名形式。"""
    body = "".join(
        f"{key}{value}"
        for key, value in sorted(params.items())
        if key != "sign" and value is not None and str(value) != ""
    )
    return hashlib.md5(f"{secret}{body}{secret}".encode("utf-8")).hexdigest().upper()
