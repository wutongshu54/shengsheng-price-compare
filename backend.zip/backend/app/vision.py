from typing import Optional

import httpx

from .config import Settings
from .models import RecognitionResponse


async def recognize_image(
    image: bytes,
    filename: str,
    content_type: Optional[str],
    settings: Settings,
    client: httpx.AsyncClient,
) -> RecognitionResponse:
    if settings.vision_api_url:
        headers = {}
        if settings.vision_api_token:
            headers["Authorization"] = f"Bearer {settings.vision_api_token}"
        response = await client.post(
            settings.vision_api_url,
            headers=headers,
            files={"image": (filename, image, content_type or "application/octet-stream")},
        )
        response.raise_for_status()
        payload = response.json()
        return RecognitionResponse(
            keyword=str(payload["keyword"]),
            confidence=float(payload.get("confidence", 0.8)),
        )

    if settings.allow_demo_fallback:
        return RecognitionResponse(keyword=settings.demo_image_keyword, confidence=0.92)
    raise RuntimeError("图片识别服务未配置")
