from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Optional

from cryptography.fernet import Fernet

from .models import Platform


class TokenStore:
    def __init__(self, database_path: str, encryption_key: str):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.fernet = Fernet(encryption_key.encode("utf-8")) if encryption_key else None
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS oauth_tokens (
                    client_session_id TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    access_token BLOB NOT NULL,
                    refresh_token BLOB,
                    expires_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (client_session_id, platform)
                )
                """
            )

    def save(
        self,
        client_session_id: str,
        platform: Platform,
        access_token: str,
        refresh_token: str = "",
        expires_at: Optional[str] = None,
    ) -> None:
        if self.fernet is None:
            raise RuntimeError("正式授权前必须配置 TOKEN_ENCRYPTION_KEY")
        now = datetime.now(timezone.utc).isoformat()
        encrypted_access = self.fernet.encrypt(access_token.encode("utf-8"))
        encrypted_refresh = self.fernet.encrypt(refresh_token.encode("utf-8")) if refresh_token else None
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO oauth_tokens (
                    client_session_id, platform, access_token, refresh_token, expires_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(client_session_id, platform) DO UPDATE SET
                    access_token=excluded.access_token,
                    refresh_token=excluded.refresh_token,
                    expires_at=excluded.expires_at,
                    updated_at=excluded.updated_at
                """,
                (
                    client_session_id,
                    platform.value,
                    encrypted_access,
                    encrypted_refresh,
                    expires_at,
                    now,
                ),
            )

    def is_authorized(self, client_session_id: str, platform: Platform) -> bool:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT 1 FROM oauth_tokens WHERE client_session_id=? AND platform=?",
                (client_session_id, platform.value),
            ).fetchone()
        return row is not None

    def get_access_token(self, client_session_id: str, platform: Platform) -> Optional[str]:
        if self.fernet is None:
            return None
        with self._connect() as connection:
            row = connection.execute(
                "SELECT access_token FROM oauth_tokens WHERE client_session_id=? AND platform=?",
                (client_session_id, platform.value),
            ).fetchone()
        if row is None:
            return None
        return self.fernet.decrypt(row[0]).decode("utf-8")

    def revoke(self, client_session_id: str, platform: Platform) -> None:
        with self._connect() as connection:
            connection.execute(
                "DELETE FROM oauth_tokens WHERE client_session_id=? AND platform=?",
                (client_session_id, platform.value),
            )

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(str(self.database_path))
