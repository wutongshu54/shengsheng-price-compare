import json
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import md5_platform_sign
from .base import PlatformAdapter, as_float, as_int, first_value, nested


class JdAdapter(PlatformAdapter):
    name = "京东"

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        request_body = {
            "goodsReqDTO": {
                "keyword": keyword,
                "pageIndex": page,
                "pageSize": min(page_size, 30),
                "sceneId": 1,
            }
        }
        params = {
            "method": "jd.union.open.goods.query",
            "app_key": self.settings.jd_app_key,
            "timestamp": datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M:%S"),
            "format": "json",
            "v": "1.0",
            "sign_method": "md5",
            "360buy_param_json": json.dumps(request_body, ensure_ascii=False, separators=(",", ":")),
        }
        if self.access_token:
            params["access_token"] = self.access_token
        params["sign"] = md5_platform_sign(params, self.settings.jd_app_secret)
        response = await self.client.post(self.settings.jd_gateway, data=params)
        response.raise_for_status()
        payload = response.json()
        if "error_response" in payload:
            error = payload["error_response"] or {}
            message = error.get("zh_desc") or error.get("en_desc") or error.get("message") or error
            raise RuntimeError(f"京东接口错误：{message}")
        response_root = (
            payload.get("jd_union_open_goods_query_responce")
            or payload.get("jd_union_open_goods_query_response")
        )
        if not isinstance(response_root, dict):
            raise RuntimeError("京东接口错误：返回结构中缺少商品查询结果")
        query_result = response_root.get("queryResult")
        if isinstance(query_result, str):
            query_result = json.loads(query_result)
        if not isinstance(query_result, dict):
            raise RuntimeError("京东接口错误：queryResult 返回格式异常")
        if str(query_result.get("code", "200")) not in {"0", "200"}:
            raise RuntimeError(f"京东接口错误：{query_result.get('message') or query_result}")
        return [self._map_item(item) for item in query_result.get("data", []) if isinstance(item, dict)]

    def _map_item(self, item: dict) -> Offer:
        price_info = item.get("priceInfo", {}) or {}
        coupons = nested(item, "couponInfo", "couponList", default=[]) or []
        coupon_data = coupons[0] if coupons and isinstance(coupons[0], dict) else {}
        price = as_float(price_info.get("price"))
        coupon = as_float(coupon_data.get("discount"))
        final_price = max(0.0, price - coupon)
        shop_info = item.get("shopInfo", {}) or {}
        owner = str(first_value(item.get("owner"), shop_info.get("shopType"), default=""))
        shop_type = ShopType.OFFICIAL if owner.lower() in {"g", "self", "official", "1"} else ShopType.POP
        raw_rating = as_float(first_value(item.get("goodCommentsShare"), item.get("goodCommentsSharePercent")))
        rating = raw_rating / 20.0 if raw_rating > 5 else raw_rating
        return Offer(
            id=str(first_value(item.get("skuId"), default="jd-unknown")),
            platform=Platform.JD,
            title=str(first_value(item.get("skuName"), default="京东商品")),
            specification=str(first_value(item.get("brandName"), item.get("categoryInfo"), default="")),
            price=price,
            originalPrice=as_float(first_value(price_info.get("lowestPrice"), price), price),
            coupon=coupon,
            finalPrice=final_price,
            rating=rating,
            reviewCount=as_int(first_value(item.get("comments"), item.get("commentCount"))),
            sales=as_int(first_value(item.get("inOrderCount30Days"), item.get("inOrderCount"))),
            shopType=shop_type,
            matchConfidence=0.86,
            productUrl=str(first_value(item.get("materialUrl"), coupon_data.get("link"), default="")),
        )
