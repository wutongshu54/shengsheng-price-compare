import asyncio
import json
import re
from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import md5_platform_sign
from .base import PlatformAdapter, as_float, as_int, first_value, nested


class JdAdapter(PlatformAdapter):
    name = "京东"
    material_elite_ids = (13270, 1, 3, 4, 22, 23)
    material_page_count = 3
    keyword_page_count = 3
    minimum_match_score = 0.65
    keyword_aliases = {
        "充电头": ("充电头", "充电器", "快充头", "电源适配器", "手机充电器", "USB充电器", "氮化镓充电器"),
        "充电器": ("充电器", "充电头", "快充头", "电源适配器", "手机充电器", "USB充电器", "氮化镓充电器"),
        "手机": ("手机", "智能手机"),
    }
    category_exclusions = {
        "充电头": ("剃须刀", "鼻毛器", "电动牙刷", "理发器", "充电宝", "移动电源"),
        "充电器": ("剃须刀", "鼻毛器", "电动牙刷", "理发器", "充电宝", "移动电源"),
        "手机": ("手机配件", "充电器", "数据线", "耳机", "支架", "保护壳", "贴膜", "摄像头"),
    }
    category_inclusions = {
        "充电头": ("充电器", "电源适配器", "手机配件", "数码配件", "车载充电器"),
        "充电器": ("充电器", "电源适配器", "手机配件", "数码配件", "车载充电器"),
        "手机": ("手机", "智能手机", "手机通讯"),
    }

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        items: list[dict] = []
        minimum_results = min(3, page_size)
        keyword_permission_denied = False

        query_keywords = self._query_keywords(keyword)
        query_plan = [(query_keyword, page) for query_keyword in query_keywords]
        query_plan.extend(
            (query_keyword, page + page_offset)
            for page_offset in range(1, self.keyword_page_count)
            for query_keyword in query_keywords
        )

        for query_keyword, page_index in query_plan:
            request_body = {
                "goodsReqDTO": {
                    "keyword": query_keyword,
                    "pageIndex": page_index,
                    "pageSize": min(page_size, 30),
                    "sceneId": 1,
                    "sortName": "price",
                    "sort": "asc",
                }
            }
            try:
                queried_items = await self._request(
                    method="jd.union.open.goods.query",
                    request_body=request_body,
                    response_keys=(
                        "jd_union_open_goods_query_responce",
                        "jd_union_open_goods_query_response",
                    ),
                )
            except RuntimeError as exc:
                if "无访问权限" not in str(exc):
                    raise
                keyword_permission_denied = True
                break
            items = self._merge_unique_items(items, queried_items)
            if len(self._filter_and_sort_items(items, keyword, page_size)) >= minimum_results:
                break

        matched_items = self._filter_and_sort_items(items, keyword, page_size)
        if keyword_permission_denied or (
            len(matched_items) < minimum_results and len(query_keywords) > 1
        ):
            try:
                material_items = await self._search_material_pools(keyword, page_size)
            except RuntimeError:
                if not matched_items:
                    raise
            else:
                items = self._merge_unique_items(items, material_items)
                matched_items = self._filter_and_sort_items(items, keyword, page_size)
        matched_items = await self._enrich_big_fields(matched_items)
        matched_items = self._filter_and_sort_items(matched_items, keyword, page_size)
        return [self._map_item(item) for item in matched_items]

    @classmethod
    def _query_keywords(cls, keyword: str) -> tuple[str, ...]:
        normalized_keyword = re.sub(r"\s+", "", keyword.strip())
        profile_key = cls._profile_key(normalized_keyword)
        if not profile_key:
            return (keyword.strip(),)
        aliases = cls.keyword_aliases[profile_key]
        matched_alias = max(
            (alias for alias in aliases if alias in normalized_keyword),
            key=len,
            default=profile_key,
        )
        queries = [keyword.strip()]
        for alias in aliases:
            candidate = normalized_keyword.replace(matched_alias, alias, 1)
            if candidate and candidate not in queries:
                queries.append(candidate)
        return tuple(queries)

    @staticmethod
    def _merge_unique_items(existing: list[dict], incoming: list[dict]) -> list[dict]:
        merged = list(existing)
        seen_ids = {
            str(first_value(item.get("skuId"), item.get("itemId"), default=""))
            for item in existing
        }
        for item in incoming:
            item_id = str(first_value(item.get("skuId"), item.get("itemId"), default=""))
            if item_id and item_id in seen_ids:
                continue
            if item_id:
                seen_ids.add(item_id)
            merged.append(item)
        return merged

    async def _search_material_pools(self, keyword: str, page_size: int) -> list[dict]:
        results = await asyncio.gather(
            *(
                self._request(
                    method="jd.union.open.goods.material.query",
                    request_body={
                        "goodsReq": {
                            "eliteId": elite_id,
                            "pageIndex": page_index,
                            "pageSize": 50,
                        }
                    },
                    response_keys=(
                        "jd_union_open_goods_material_query_responce",
                        "jd_union_open_goods_material_query_response",
                    ),
                    empty_codes={"2003202"},
                )
                for page_index in range(1, self.material_page_count + 1)
                for elite_id in self.material_elite_ids
            ),
            return_exceptions=True,
        )
        items: list[dict] = []
        errors: list[Exception] = []
        seen_ids: set[str] = set()
        for result in results:
            if isinstance(result, Exception):
                errors.append(result)
                continue
            for item in result:
                item_id = str(first_value(item.get("skuId"), item.get("itemId"), default=""))
                if item_id and item_id in seen_ids:
                    continue
                if item_id:
                    seen_ids.add(item_id)
                items.append(item)
        if items:
            return items
        if len(errors) == len(results) and errors:
            raise RuntimeError(str(errors[0]))
        raise RuntimeError("京东关键词查询权限尚未开通，精选商品池中暂无匹配商品")

    async def _enrich_big_fields(self, items: list[dict]) -> list[dict]:
        item_ids = list(dict.fromkeys(
            str(item.get("itemId"))
            for item in items
            if item.get("itemId")
        ))[:10]
        if not item_ids:
            return items
        try:
            details = await self._request(
                method="jd.union.open.goods.bigfield.query",
                request_body={
                    "goodsReq": {
                        "itemIds": item_ids,
                        "fields": ["categoryInfo", "imageInfo", "baseBigFieldInfo"],
                        "sceneId": 1,
                    }
                },
                response_keys=(
                    "jd_union_open_goods_bigfield_query_responce",
                    "jd_union_open_goods_bigfield_query_response",
                ),
                data_key="bigFieldGoodsResp",
            )
        except (httpx.HTTPError, KeyError, RuntimeError, ValueError):
            return items

        details_by_id: dict[str, dict] = {}
        for detail in details:
            for key in ("itemId", "callerItemId", "skuId"):
                value = detail.get(key)
                if value:
                    details_by_id[str(value)] = detail

        enriched: list[dict] = []
        for item in items:
            detail = next(
                (
                    details_by_id[str(item[key])]
                    for key in ("itemId", "skuId")
                    if item.get(key) and str(item[key]) in details_by_id
                ),
                None,
            )
            if not detail:
                enriched.append(item)
                continue
            merged = dict(item)
            for field in ("categoryInfo", "imageInfo", "baseBigFieldInfo", "skuName", "brandName"):
                if detail.get(field):
                    merged[field] = detail[field]
            enriched.append(merged)
        return enriched

    async def _request(
        self,
        *,
        method: str,
        request_body: dict,
        response_keys: tuple[str, str],
        empty_codes: Optional[set[str]] = None,
        data_key: Optional[str] = None,
    ) -> list[dict]:
        params = {
            "method": method,
            "app_key": self.settings.jd_app_key,
            "timestamp": datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M:%S"),
            "format": "json",
            "v": "1.0",
            "sign_method": "md5",
            "360buy_param_json": json.dumps(request_body, ensure_ascii=False, separators=(",", ":")),
        }
        if self.access_token:
            params["access_token"] = self.access_token
        params["sign"] = md5_platform_sign(params, self.settings.jd_app_secret)
        response = await self.client.post(self.settings.jd_gateway, data=params)
        response.raise_for_status()
        payload = response.json()
        if "error_response" in payload:
            error = payload["error_response"] or {}
            message = error.get("zh_desc") or error.get("en_desc") or error.get("message") or error
            raise RuntimeError(f"京东接口错误：{message}")
        response_root = payload.get(response_keys[0]) or payload.get(response_keys[1])
        if not isinstance(response_root, dict):
            raise RuntimeError("京东接口错误：返回结构中缺少商品查询结果")
        query_result = response_root.get("queryResult")
        if isinstance(query_result, str):
            query_result = json.loads(query_result)
        if not isinstance(query_result, dict):
            raise RuntimeError("京东接口错误：queryResult 返回格式异常")
        result_code = str(query_result.get("code", "200"))
        if empty_codes and result_code in empty_codes:
            return []
        if result_code not in {"0", "200"}:
            raise RuntimeError(f"京东接口错误：{query_result.get('message') or query_result}")
        data = query_result.get("data", [])
        if data_key and isinstance(data, dict):
            data = data.get(data_key, [])
        elif data_key and isinstance(data, list):
            data = [
                item.get(data_key, item) if isinstance(item, dict) else item
                for item in data
            ]
        if isinstance(data, dict):
            data = [data]
        return [item for item in data if isinstance(item, dict)]

    @classmethod
    def _filter_and_sort_items(cls, items: list[dict], keyword: str, page_size: int) -> list[dict]:
        matched: list[dict] = []
        for item in items:
            score = cls._match_score(item, keyword)
            if score < cls.minimum_match_score:
                continue
            candidate = dict(item)
            candidate["_matchConfidence"] = score
            matched.append(candidate)
        matched.sort(
            key=lambda item: (
                cls._effective_price(item)[2],
                -as_float(item.get("_matchConfidence")),
                -as_int(first_value(item.get("inOrderCount30Days"), item.get("inOrderCount"))),
            )
        )
        return matched[:page_size]

    @classmethod
    def _matches_keyword(cls, item: dict, keyword: str) -> bool:
        return cls._match_score(item, keyword) >= cls.minimum_match_score

    @classmethod
    def _match_score(cls, item: dict, keyword: str) -> float:
        title_and_brand = " ".join(
            str(value)
            for value in (
                item.get("skuName"),
                item.get("brandName"),
            )
            if value
        ).lower()
        category = cls._category_text(item).lower()
        normalized_searchable = re.sub(r"\s+", "", title_and_brand)
        keyword_parts = re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]+", keyword.lower())
        if not keyword_parts:
            return 0.0
        normalized_keyword = "".join(keyword_parts)
        profile_key = cls._profile_key(normalized_keyword)
        aliases = cls.keyword_aliases.get(profile_key, (normalized_keyword,))
        excluded_categories = cls.category_exclusions.get(profile_key, ())
        combined_searchable = f"{title_and_brand} {category}"
        if excluded_categories and any(term in combined_searchable for term in excluded_categories):
            return 0.0
        if profile_key in {"充电头", "充电器"} and re.search(
            r"(?:赠|送|配|含|附带|搭配).{0,8}(?:充电头|充电器|快充头|电源适配器)",
            title_and_brand,
        ):
            return 0.0

        if profile_key:
            normalized_aliases = tuple(re.sub(r"\s+", "", alias.lower()) for alias in aliases)
            if not any(alias in normalized_searchable for alias in normalized_aliases):
                return 0.0
            included_categories = cls.category_inclusions.get(profile_key, ())
            category_matches = any(term in category for term in included_categories)

            score = 0.55
            score += 0.25 if category_matches else 0.10
            if normalized_keyword in normalized_searchable:
                score += 0.15
            qualifiers = [
                part for part in keyword_parts
                if not any(part in alias or alias in part for alias in normalized_aliases)
            ]
            if qualifiers:
                matched_qualifiers = sum(part in normalized_searchable for part in qualifiers)
                score += 0.10 * matched_qualifiers / len(qualifiers)
            return min(1.0, score)

        if normalized_keyword in normalized_searchable:
            return 0.95
        if all(part in normalized_searchable for part in keyword_parts):
            return 0.85
        coverages: list[float] = []
        for part in keyword_parts:
            if not re.fullmatch(r"[\u4e00-\u9fff]{3,}", part):
                return 0.0
            pairs = [part[index:index + 2] for index in range(len(part) - 1)]
            matched_pairs = sum(pair in normalized_searchable for pair in pairs)
            coverages.append(matched_pairs / len(pairs))
        coverage = sum(coverages) / len(coverages)
        return 0.45 + 0.45 * coverage if coverage >= 0.6 else 0.0

    @classmethod
    def _profile_key(cls, normalized_keyword: str) -> str:
        return max(
            (
                key
                for key, aliases in cls.keyword_aliases.items()
                if any(alias in normalized_keyword for alias in aliases)
            ),
            key=len,
            default="",
        )

    @staticmethod
    def _category_text(item: dict) -> str:
        category_info = item.get("categoryInfo", {}) or {}
        if not isinstance(category_info, dict):
            return str(category_info)
        return " ".join(
            str(category_info.get(key) or "")
            for key in ("cid1Name", "cid2Name", "cid3Name")
        ).strip()

    @staticmethod
    def _effective_price(item: dict) -> tuple[float, float, float]:
        price_info = item.get("priceInfo", {}) or {}
        price = as_float(price_info.get("price"))
        direct_price = as_float(price_info.get("lowestCouponPrice"))
        coupon_discount = 0.0
        coupons = nested(item, "couponInfo", "couponList", default=[]) or []
        for coupon in coupons:
            if not isinstance(coupon, dict):
                continue
            discount = as_float(coupon.get("discount"))
            quota = as_float(coupon.get("quota"))
            if discount > coupon_discount and (quota <= 0 or price >= quota):
                coupon_discount = discount
        coupon_price = max(0.0, price - coupon_discount)
        if 0 < direct_price <= price and direct_price < coupon_price:
            return price, price - direct_price, direct_price
        return price, coupon_discount, coupon_price

    def _map_item(self, item: dict) -> Offer:
        price_info = item.get("priceInfo", {}) or {}
        coupons = nested(item, "couponInfo", "couponList", default=[]) or []
        valid_coupons = [
            coupon for coupon in coupons
            if isinstance(coupon, dict)
            and as_float(coupon.get("discount")) > 0
            and (as_float(coupon.get("quota")) <= 0 or as_float(price_info.get("price")) >= as_float(coupon.get("quota")))
        ]
        coupon_data = max(valid_coupons, key=lambda value: as_float(value.get("discount")), default={})
        price, coupon, final_price = self._effective_price(item)
        shop_info = item.get("shopInfo", {}) or {}
        owner = str(first_value(item.get("owner"), shop_info.get("shopType"), default=""))
        shop_type = ShopType.OFFICIAL if owner.lower() in {"g", "self", "official", "1"} else ShopType.POP
        raw_rating = as_float(first_value(item.get("goodCommentsShare"), item.get("goodCommentsSharePercent")))
        rating = raw_rating / 20.0 if raw_rating > 5 else raw_rating
        product_url = str(first_value(item.get("materialUrl"), coupon_data.get("link"), default=""))
        if product_url and not product_url.startswith(("http://", "https://")):
            product_url = f"https://{product_url.lstrip('/')}"
        return Offer(
            id=str(first_value(item.get("skuId"), item.get("itemId"), product_url, default="jd-unknown")),
            platform=Platform.JD,
            title=str(first_value(item.get("skuName"), default="京东商品")),
            specification=str(first_value(item.get("brandName"), self._category_text(item), default="")),
            price=price,
            originalPrice=price,
            coupon=coupon,
            finalPrice=final_price,
            rating=rating,
            reviewCount=as_int(first_value(item.get("comments"), item.get("commentCount"))),
            sales=as_int(first_value(item.get("inOrderCount30Days"), item.get("inOrderCount"))),
            shopType=shop_type,
            matchConfidence=as_float(item.get("_matchConfidence"), 0.8),
            productUrl=product_url,
        )
