import asyncio
import json
import re
from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import md5_platform_sign
from .base import PlatformAdapter, as_float, as_int, first_value, nested


class JdAdapter(PlatformAdapter):
    name = "京东"
    material_elite_ids = (13270, 1, 3, 4, 22, 23)
    keyword_aliases = {
        "充电头": ("充电头", "充电器", "快充头", "电源适配器"),
        "充电器": ("充电器", "充电头", "快充头", "电源适配器"),
        "手机": ("手机", "智能手机"),
    }
    category_exclusions = {
        "充电头": ("剃须刀", "鼻毛器", "电动牙刷", "理发器"),
        "充电器": ("剃须刀", "鼻毛器", "电动牙刷", "理发器"),
        "手机": ("手机配件", "充电器", "数据线", "耳机", "支架", "保护壳", "贴膜", "摄像头"),
    }

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        request_body = {
            "goodsReqDTO": {
                "keyword": keyword,
                "pageIndex": page,
                "pageSize": min(page_size, 30),
                "sceneId": 1,
            }
        }
        try:
            items = await self._request(
                method="jd.union.open.goods.query",
                request_body=request_body,
                response_keys=(
                    "jd_union_open_goods_query_responce",
                    "jd_union_open_goods_query_response",
                ),
            )
        except RuntimeError as exc:
            if "无访问权限" not in str(exc):
                raise
            items = await self._search_material_pools(keyword, page_size)
        return [self._map_item(item) for item in items]

    async def _search_material_pools(self, keyword: str, page_size: int) -> list[dict]:
        results = await asyncio.gather(
            *(
                self._request(
                    method="jd.union.open.goods.material.query",
                    request_body={
                        "goodsReq": {
                            "eliteId": elite_id,
                            "pageIndex": 1,
                            "pageSize": 50,
                        }
                    },
                    response_keys=(
                        "jd_union_open_goods_material_query_responce",
                        "jd_union_open_goods_material_query_response",
                    ),
                    empty_codes={"2003202"},
                )
                for elite_id in self.material_elite_ids
            ),
            return_exceptions=True,
        )
        items: list[dict] = []
        errors: list[Exception] = []
        seen_ids: set[str] = set()
        for result in results:
            if isinstance(result, Exception):
                errors.append(result)
                continue
            for item in result:
                item_id = str(first_value(item.get("skuId"), item.get("itemId"), default=""))
                if item_id and item_id in seen_ids:
                    continue
                if item_id:
                    seen_ids.add(item_id)
                if self._matches_keyword(item, keyword):
                    items.append(item)
        if items:
            return items[:page_size]
        if len(errors) == len(results) and errors:
            raise RuntimeError(str(errors[0]))
        raise RuntimeError("京东关键词查询权限尚未开通，精选商品池中暂无匹配商品")

    async def _request(
        self,
        *,
        method: str,
        request_body: dict,
        response_keys: tuple[str, str],
        empty_codes: Optional[set[str]] = None,
    ) -> list[dict]:
        params = {
            "method": method,
            "app_key": self.settings.jd_app_key,
            "timestamp": datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M:%S"),
            "format": "json",
            "v": "1.0",
            "sign_method": "md5",
            "360buy_param_json": json.dumps(request_body, ensure_ascii=False, separators=(",", ":")),
        }
        if self.access_token:
            params["access_token"] = self.access_token
        params["sign"] = md5_platform_sign(params, self.settings.jd_app_secret)
        response = await self.client.post(self.settings.jd_gateway, data=params)
        response.raise_for_status()
        payload = response.json()
        if "error_response" in payload:
            error = payload["error_response"] or {}
            message = error.get("zh_desc") or error.get("en_desc") or error.get("message") or error
            raise RuntimeError(f"京东接口错误：{message}")
        response_root = payload.get(response_keys[0]) or payload.get(response_keys[1])
        if not isinstance(response_root, dict):
            raise RuntimeError("京东接口错误：返回结构中缺少商品查询结果")
        query_result = response_root.get("queryResult")
        if isinstance(query_result, str):
            query_result = json.loads(query_result)
        if not isinstance(query_result, dict):
            raise RuntimeError("京东接口错误：queryResult 返回格式异常")
        result_code = str(query_result.get("code", "200"))
        if empty_codes and result_code in empty_codes:
            return []
        if result_code not in {"0", "200"}:
            raise RuntimeError(f"京东接口错误：{query_result.get('message') or query_result}")
        return [item for item in query_result.get("data", []) if isinstance(item, dict)]

    @staticmethod
    def _matches_keyword(item: dict, keyword: str) -> bool:
        title_and_brand = " ".join(
            str(value)
            for value in (
                item.get("skuName"),
                item.get("brandName"),
            )
            if value
        ).lower()
        category_info = item.get("categoryInfo", {}) or {}
        category = " ".join(
            str(category_info.get(key) or "")
            for key in ("cid1Name", "cid2Name", "cid3Name")
        ).lower()
        normalized_searchable = re.sub(r"\s+", "", title_and_brand)
        keyword_parts = re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]+", keyword.lower())
        if not keyword_parts:
            return False
        normalized_keyword = "".join(keyword_parts)
        aliases = JdAdapter.keyword_aliases.get(normalized_keyword, (normalized_keyword,))
        excluded_categories = JdAdapter.category_exclusions.get(normalized_keyword, ())
        if excluded_categories and any(term in category for term in excluded_categories):
            return False
        if any(re.sub(r"\s+", "", alias) in normalized_searchable for alias in aliases):
            return True
        if all(part in normalized_searchable for part in keyword_parts):
            return True
        for part in keyword_parts:
            if not re.fullmatch(r"[\u4e00-\u9fff]{3,}", part):
                return False
            pairs = [part[index:index + 2] for index in range(len(part) - 1)]
            matched_pairs = sum(pair in normalized_searchable for pair in pairs)
            if matched_pairs / len(pairs) < 0.6:
                return False
        return True

    def _map_item(self, item: dict) -> Offer:
        price_info = item.get("priceInfo", {}) or {}
        coupons = nested(item, "couponInfo", "couponList", default=[]) or []
        coupon_data = coupons[0] if coupons and isinstance(coupons[0], dict) else {}
        price = as_float(price_info.get("price"))
        coupon = as_float(coupon_data.get("discount"))
        final_price = max(0.0, price - coupon)
        shop_info = item.get("shopInfo", {}) or {}
        owner = str(first_value(item.get("owner"), shop_info.get("shopType"), default=""))
        shop_type = ShopType.OFFICIAL if owner.lower() in {"g", "self", "official", "1"} else ShopType.POP
        raw_rating = as_float(first_value(item.get("goodCommentsShare"), item.get("goodCommentsSharePercent")))
        rating = raw_rating / 20.0 if raw_rating > 5 else raw_rating
        product_url = str(first_value(item.get("materialUrl"), coupon_data.get("link"), default=""))
        if product_url and not product_url.startswith(("http://", "https://")):
            product_url = f"https://{product_url.lstrip('/')}"
        return Offer(
            id=str(first_value(item.get("skuId"), item.get("itemId"), product_url, default="jd-unknown")),
            platform=Platform.JD,
            title=str(first_value(item.get("skuName"), default="京东商品")),
            specification=str(first_value(item.get("brandName"), item.get("categoryInfo"), default="")),
            price=price,
            originalPrice=as_float(first_value(price_info.get("lowestPrice"), price), price),
            coupon=coupon,
            finalPrice=final_price,
            rating=rating,
            reviewCount=as_int(first_value(item.get("comments"), item.get("commentCount"))),
            sales=as_int(first_value(item.get("inOrderCount30Days"), item.get("inOrderCount"))),
            shopType=shop_type,
            matchConfidence=0.86,
            productUrl=product_url,
        )
