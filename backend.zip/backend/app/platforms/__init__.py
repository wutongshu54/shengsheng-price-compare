from .jd import JdAdapter
from .pdd import PddAdapter
from .taobao import TaobaoAdapter

__all__ = ["TaobaoAdapter", "JdAdapter", "PddAdapter"]
