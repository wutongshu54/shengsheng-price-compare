from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import md5_platform_sign
from .base import PlatformAdapter, as_float, as_int, first_list, first_value, nested


class TaobaoAdapter(PlatformAdapter):
    name = "淘宝"

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        params = {
            "method": "taobao.tbk.dg.material.optional.upgrade",
            "app_key": self.settings.taobao_app_key,
            "timestamp": datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d %H:%M:%S"),
            "format": "json",
            "v": "2.0",
            "sign_method": "md5",
            "adzone_id": self.settings.taobao_adzone_id,
            "q": keyword,
            "page_no": page,
            "page_size": min(page_size, 100),
        }
        if self.access_token:
            params["session"] = self.access_token
        params["sign"] = md5_platform_sign(params, self.settings.taobao_app_secret)
        response = await self.client.post(self.settings.taobao_gateway, data=params)
        response.raise_for_status()
        payload = response.json()
        if "error_response" in payload:
            error = payload["error_response"]
            raise RuntimeError(f"淘宝接口错误：{error.get('sub_msg') or error.get('msg') or error}")

        root = payload.get("tbk_dg_material_optional_upgrade_response", {})
        raw_items = first_list(nested(root, "result_list", default=[]))
        return [self._map_item(item) for item in raw_items if isinstance(item, dict)]

    def _map_item(self, item: dict) -> Offer:
        basic = nested(item, "item_basic_info", default={}) or {}
        price_info = nested(item, "price_promotion_info", default={}) or {}
        shop = nested(item, "shop_info", default={}) or {}
        publish = nested(item, "publish_info", default={}) or {}
        item_id = str(first_value(basic.get("item_id"), item.get("item_id"), default="taobao-unknown"))
        title = str(first_value(basic.get("title"), item.get("title"), default="淘宝商品"))
        final_promotion_price = as_float(price_info.get("final_promotion_price"))
        price = as_float(first_value(
            price_info.get("zk_final_price"),
            item.get("zk_final_price"),
            item.get("reserve_price"),
            final_promotion_price,
        ))
        original_price = as_float(first_value(
            price_info.get("original_price"),
            item.get("reserve_price"),
            price,
        ), price)
        coupon = as_float(first_value(
            price_info.get("coupon_amount"),
            item.get("coupon_amount"),
            default=0,
        ))
        final_price = final_promotion_price if final_promotion_price > 0 else max(0.0, price - coupon)
        seller_type = str(first_value(shop.get("seller_type"), item.get("user_type"), default=""))
        shop_type = ShopType.FLAGSHIP if seller_type in {"1", "B", "b"} else ShopType.POP
        return Offer(
            id=item_id,
            platform=Platform.TAOBAO,
            title=title,
            specification=str(first_value(basic.get("short_title"), basic.get("category_name"), default="")),
            price=price,
            originalPrice=original_price,
            coupon=coupon,
            finalPrice=final_price,
            rating=as_float(first_value(nested(shop, "dsr_info", "dsr_score"), item.get("shop_dsr"))),
            reviewCount=as_int(first_value(item.get("comment_count"), item.get("volume"))),
            sales=as_int(first_value(basic.get("volume"), item.get("volume"))),
            shopType=shop_type,
            matchConfidence=0.86,
            productUrl=str(first_value(
                publish.get("click_url"),
                item.get("click_url"),
                basic.get("item_url"),
                default="",
            )),
        )
