from datetime import datetime
import re

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import md5_platform_sign
from .base import PlatformAdapter, as_float, as_int, first_value


class PddAdapter(PlatformAdapter):
    name = "拼多多"

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token or settings.pdd_access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        params = {
            "type": "pdd.ddk.oauth.goods.search",
            "client_id": self.settings.pdd_client_id,
            "access_token": self.access_token,
            "timestamp": int(datetime.now().timestamp()),
            "data_type": "JSON",
            "keyword": keyword,
            "page": page,
            "page_size": min(page_size, 100),
        }
        if self.settings.pdd_pid:
            params["pid"] = self.settings.pdd_pid
        params["sign"] = md5_platform_sign(params, self.settings.pdd_client_secret)
        response = await self.client.post(self.settings.pdd_gateway, data=params)
        response.raise_for_status()
        payload = response.json()
        if "error_response" in payload:
            error = payload["error_response"]
            raise RuntimeError(f"拼多多接口错误：{error.get('error_msg') or error}")
        raw_items = (payload.get("goods_search_response") or {}).get("goods_list", [])
        return [self._map_item(item) for item in raw_items if isinstance(item, dict)]

    def _map_item(self, item: dict) -> Offer:
        price = as_float(item.get("min_group_price")) / 100.0
        coupon = as_float(item.get("coupon_discount")) / 100.0
        original_price = as_float(first_value(item.get("min_normal_price"), item.get("min_group_price"))) / 100.0
        goods_id = str(first_value(item.get("goods_sign"), item.get("goods_id"), default="pdd-unknown"))
        raw_rating = as_float(item.get("goods_eval_score"))
        rating = raw_rating / 100.0 if raw_rating > 5 else raw_rating
        mall_name = str(item.get("mall_name") or "")
        shop_type = ShopType.FLAGSHIP if "旗舰" in mall_name else ShopType.POP
        numeric_goods_id = item.get("goods_id")
        product_url = (
            f"https://mobile.yangkeduo.com/goods.html?goods_id={numeric_goods_id}"
            if numeric_goods_id
            else ""
        )
        return Offer(
            id=goods_id,
            platform=Platform.PDD,
            title=str(first_value(item.get("goods_name"), default="拼多多商品")),
            specification=str(first_value(item.get("goods_desc"), item.get("opt_name"), default="")),
            price=price,
            originalPrice=original_price,
            coupon=coupon,
            finalPrice=max(0.0, price - coupon),
            rating=rating,
            reviewCount=as_int(item.get("goods_eval_count")),
            sales=_parse_sales(item.get("sales_tip")),
            shopType=shop_type,
            matchConfidence=0.84,
            productUrl=product_url,
        )


def _parse_sales(value: object) -> int:
    text = str(value or "").strip().replace(",", "")
    match = re.search(r"([\d.]+)", text)
    if not match:
        return as_int(value)
    number = float(match.group(1))
    if "万" in text:
        number *= 10_000
    elif "千" in text:
        number *= 1_000
    return int(number)
