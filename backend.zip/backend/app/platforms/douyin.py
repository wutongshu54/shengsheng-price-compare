import json
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

from ..config import Settings
from ..models import Offer, Platform, ShopType
from ..signing import douyin_hmac_sha256_sign
from .base import PlatformAdapter, as_float, as_int, first_value


class DouyinAdapter(PlatformAdapter):
    name = "抖音"
    method = "buyin.kolMaterialsProductsSearch"
    api_path = "/buyin/kolMaterialsProductsSearch"

    def __init__(self, client: httpx.AsyncClient, settings: Settings, access_token: str = ""):
        super().__init__(client)
        self.settings = settings
        self.access_token = access_token or settings.douyin_access_token

    async def search(self, keyword: str, page: int, page_size: int) -> list[Offer]:
        business_params = {
            "page": page,
            "page_size": min(page_size, 20),
            "search_type": 0,
            "share_status": 1,
            "sort_type": 0,
            "title": keyword,
        }
        param_json = json.dumps(
            business_params,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        timestamp = str(int(datetime.now(ZoneInfo("Asia/Shanghai")).timestamp()))
        query = {
            "method": self.method,
            "app_key": self.settings.douyin_app_key,
            "access_token": self.access_token,
            "timestamp": timestamp,
            "v": "2",
            "sign_method": "hmac-sha256",
            "sign": douyin_hmac_sha256_sign(
                app_key=self.settings.douyin_app_key,
                app_secret=self.settings.douyin_app_secret,
                method=self.method,
                param_json=param_json,
                timestamp=timestamp,
            ),
        }
        response = await self.client.post(
            f"{self.settings.douyin_gateway.rstrip('/')}{self.api_path}",
            params=query,
            content=param_json.encode("utf-8"),
            headers={"Content-Type": "application/json; charset=utf-8"},
        )
        response.raise_for_status()
        payload = response.json()
        if str(payload.get("code")) != "10000":
            message = payload.get("sub_msg") or payload.get("msg") or payload
            raise RuntimeError(f"抖音接口错误：{message}")
        raw_items = (payload.get("data") or {}).get("products", [])
        return [self._map_item(item) for item in raw_items if isinstance(item, dict)]

    def _map_item(self, item: dict) -> Offer:
        price = as_float(item.get("price")) / 100.0
        coupon_price = as_float(item.get("coupon_price")) / 100.0
        final_price = coupon_price if coupon_price > 0 else price
        shop_name = str(item.get("shop_name") or "")
        return Offer(
            id=str(first_value(item.get("product_id"), default="douyin-unknown")),
            platform=Platform.DOUYIN,
            title=str(first_value(item.get("title"), default="抖音商品")),
            specification=shop_name,
            price=price,
            originalPrice=price,
            coupon=max(0.0, price - final_price),
            finalPrice=final_price,
            rating=0,
            reviewCount=0,
            sales=as_int(item.get("sales")),
            shopType=ShopType.FLAGSHIP if "旗舰" in shop_name else ShopType.POP,
            matchConfidence=0.83,
            productUrl=str(first_value(item.get("detail_url"), default="")),
        )
