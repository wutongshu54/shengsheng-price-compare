import math
from typing import List

from .models import Offer, SortOption


MINIMUM_RECOMMENDATION_SAMPLE = 3


def rank_offers(offers: List[Offer], sort: SortOption) -> List[Offer]:
    if not offers:
        return []

    scored: list[tuple[Offer, float, float]] = []
    platforms = dict.fromkeys(offer.platform for offer in offers)
    for platform in platforms:
        platform_offers = [offer for offer in offers if offer.platform == platform]
        prices = [offer.finalPrice for offer in platform_offers]
        min_price = min(prices)
        max_price = max(prices)
        max_reviews = max(math.log(offer.reviewCount + 1) for offer in platform_offers)
        max_sales = max(math.log(offer.sales + 1) for offer in platform_offers)

        platform_scored: list[tuple[Offer, float, float]] = []
        for offer in platform_offers:
            price_score = (
                1.0
                if min_price == max_price
                else (max_price - offer.finalPrice) / (max_price - min_price)
            )
            rating_score = max(0.0, min(1.0, offer.rating / 5.0))
            review_score = math.log(offer.reviewCount + 1) / max_reviews if max_reviews else 0.0
            sales_score = math.log(offer.sales + 1) / max_sales if max_sales else 0.0
            match_score = max(0.0, min(1.0, offer.matchConfidence))
            composite = (
                0.45 * price_score
                + 0.10 * rating_score
                + 0.10 * review_score
                + 0.05 * sales_score
                + 0.30 * match_score
            )
            quality = (
                0.10 * rating_score
                + 0.10 * review_score
                + 0.05 * sales_score
                + 0.30 * match_score
            )
            value = quality / offer.finalPrice if offer.finalPrice > 0 else 0.0
            platform_scored.append((offer, composite, value))

        if len(platform_scored) >= MINIMUM_RECOMMENDATION_SAMPLE:
            cheapest = sorted(platform_scored, key=lambda item: (item[0].finalPrice, -item[1]))[:3]
            best_value = sorted(platform_scored, key=lambda item: (-item[2], -item[1]))[:3]
            cheapest_ids = {offer.id for offer, _, _ in cheapest}
            best_value_ids = {offer.id for offer, _, value in best_value if value > 0}
            for offer, _, value in platform_scored:
                offer.lowestPrice = offer.id in cheapest_ids
                offer.bestValue = offer.id in best_value_ids and value > 0
        else:
            for offer, _, _ in platform_scored:
                offer.lowestPrice = False
                offer.bestValue = False

        scored.extend(platform_scored)

    if sort == SortOption.price_lowest:
        scored.sort(key=lambda item: (item[0].finalPrice, -item[1]))
    elif sort == SortOption.rating_first:
        scored.sort(key=lambda item: (-item[0].rating, -item[0].reviewCount, -item[1]))
    else:
        scored.sort(key=lambda item: (-item[1], item[0].finalPrice))
    return [offer for offer, _, _ in scored]
