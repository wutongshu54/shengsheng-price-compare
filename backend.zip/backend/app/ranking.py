import math
from typing import List

from .models import Offer, SortOption


def rank_offers(offers: List[Offer], sort: SortOption) -> List[Offer]:
    if not offers:
        return []

    prices = [offer.finalPrice for offer in offers]
    min_price = min(prices)
    max_price = max(prices)
    max_reviews = max(math.log(offer.reviewCount + 1) for offer in offers)
    max_sales = max(math.log(offer.sales + 1) for offer in offers)

    scored = []
    for offer in offers:
        price_score = 1.0 if min_price == max_price else (max_price - offer.finalPrice) / (max_price - min_price)
        rating_score = max(0.0, min(1.0, offer.rating / 5.0))
        review_score = math.log(offer.reviewCount + 1) / max_reviews if max_reviews else 0.0
        sales_score = math.log(offer.sales + 1) / max_sales if max_sales else 0.0
        match_score = max(0.0, min(1.0, offer.matchConfidence))
        composite = (
            0.35 * price_score
            + 0.25 * rating_score
            + 0.15 * review_score
            + 0.10 * sales_score
            + 0.15 * match_score
        )
        quality = 0.25 * rating_score + 0.15 * review_score + 0.10 * sales_score + 0.15 * match_score
        value = quality / offer.finalPrice if offer.finalPrice > 0 else 0.0
        scored.append((offer, composite, value))

    best_value = max(value for _, _, value in scored)
    for offer, _, value in scored:
        offer.lowestPrice = offer.finalPrice == min_price
        offer.bestValue = value == best_value and best_value > 0

    if sort == SortOption.price_lowest:
        scored.sort(key=lambda item: (item[0].finalPrice, -item[1]))
    elif sort == SortOption.rating_first:
        scored.sort(key=lambda item: (-item[0].rating, -item[0].reviewCount, -item[1]))
    else:
        scored.sort(key=lambda item: (-item[1], item[0].finalPrice))
    return [offer for offer, _, _ in scored]
