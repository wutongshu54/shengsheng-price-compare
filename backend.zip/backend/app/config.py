from dataclasses import dataclass
import os


def _enabled(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    allow_demo_fallback: bool = _enabled("ALLOW_DEMO_FALLBACK", True)
    demo_image_keyword: str = os.getenv("DEMO_IMAGE_KEYWORD", "白色运动鞋")

    taobao_app_key: str = os.getenv("TAOBAO_APP_KEY", "")
    taobao_app_secret: str = os.getenv("TAOBAO_APP_SECRET", "")
    taobao_adzone_id: str = os.getenv("TAOBAO_ADZONE_ID", "")
    taobao_gateway: str = os.getenv("TAOBAO_GATEWAY", "https://eco.taobao.com/router/rest")

    jd_app_key: str = os.getenv("JD_APP_KEY", "")
    jd_app_secret: str = os.getenv("JD_APP_SECRET", "")
    jd_access_token: str = os.getenv("JD_ACCESS_TOKEN", "")
    jd_union_id: str = os.getenv("JD_UNION_ID", "")
    jd_gateway: str = os.getenv("JD_GATEWAY", "https://api.jd.com/routerjson")

    pdd_client_id: str = os.getenv("PDD_CLIENT_ID", "")
    pdd_client_secret: str = os.getenv("PDD_CLIENT_SECRET", "")
    pdd_access_token: str = os.getenv("PDD_ACCESS_TOKEN", "")
    pdd_pid: str = os.getenv("PDD_PID", "")
    pdd_gateway: str = os.getenv("PDD_GATEWAY", "https://gw-api.pinduoduo.com/api/router")

    douyin_app_key: str = os.getenv("DOUYIN_APP_KEY", "")
    douyin_app_secret: str = os.getenv("DOUYIN_APP_SECRET", "")
    douyin_access_token: str = os.getenv("DOUYIN_ACCESS_TOKEN", "")
    douyin_gateway: str = os.getenv("DOUYIN_GATEWAY", "https://openapi-fxg.jinritemai.com")

    vision_api_url: str = os.getenv("VISION_API_URL", "")
    vision_api_token: str = os.getenv("VISION_API_TOKEN", "")

    public_base_url: str = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000")
    app_return_url: str = os.getenv("APP_RETURN_URL", "pricecompare://oauth-complete")
    token_database_path: str = os.getenv("TOKEN_DATABASE_PATH", "data/tokens.db")
    token_encryption_key: str = os.getenv("TOKEN_ENCRYPTION_KEY", "")

    taobao_auth_url: str = os.getenv("TAOBAO_AUTH_URL", "https://oauth.taobao.com/authorize")
    taobao_token_url: str = os.getenv("TAOBAO_TOKEN_URL", "https://oauth.taobao.com/token")
    taobao_oauth_scope: str = os.getenv("TAOBAO_OAUTH_SCOPE", "")

    jd_auth_url: str = os.getenv("JD_AUTH_URL", "")
    jd_token_url: str = os.getenv("JD_TOKEN_URL", "")
    jd_oauth_scope: str = os.getenv("JD_OAUTH_SCOPE", "")

    pdd_auth_url: str = os.getenv("PDD_AUTH_URL", "https://jinbao.pinduoduo.com/open.html")
    pdd_oauth_scope: str = os.getenv("PDD_OAUTH_SCOPE", "")

    @property
    def taobao_enabled(self) -> bool:
        return all((self.taobao_app_key, self.taobao_app_secret, self.taobao_adzone_id))

    @property
    def jd_enabled(self) -> bool:
        return all((self.jd_app_key, self.jd_app_secret))

    @property
    def pdd_enabled(self) -> bool:
        return all((self.pdd_client_id, self.pdd_client_secret))

    @property
    def douyin_enabled(self) -> bool:
        return all((self.douyin_app_key, self.douyin_app_secret, self.douyin_access_token))
