from .models import Offer, Platform, ShopType


def demo_offers(keyword: str) -> list[Offer]:
    normalized = keyword.lower()
    if not any(token in normalized for token in ("鞋", "sneaker", "shoe")):
        return []
    return [
        Offer(
            id="tb-demo-1",
            platform=Platform.TAOBAO,
            title="小白鞋女新款百搭厚底运动板鞋",
            specification="白色 / 38码 / 头层牛皮",
            price=219,
            originalPrice=299,
            coupon=30,
            finalPrice=189,
            rating=4.8,
            reviewCount=12800,
            sales=46000,
            shopType=ShopType.FLAGSHIP,
            matchConfidence=0.95,
            productUrl="https://example.com/taobao/tb-demo-1",
        ),
        Offer(
            id="jd-demo-1",
            platform=Platform.JD,
            title="男女同款经典白色低帮运动休闲鞋",
            specification="白色 / 标准码 / 透气网面",
            price=199,
            originalPrice=259,
            coupon=20,
            finalPrice=179,
            rating=4.9,
            reviewCount=30500,
            sales=88000,
            shopType=ShopType.OFFICIAL,
            matchConfidence=0.90,
            productUrl="https://example.com/jd/jd-demo-1",
        ),
        Offer(
            id="pdd-demo-1",
            platform=Platform.PDD,
            title="百亿补贴纯白色轻便跑步运动鞋",
            specification="白色 / 39码 / 软底减震",
            price=129,
            originalPrice=189,
            coupon=15,
            finalPrice=114,
            rating=4.6,
            reviewCount=5400,
            sales=210000,
            shopType=ShopType.POP,
            matchConfidence=0.82,
            productUrl="https://example.com/pdd/pdd-demo-1",
        ),
    ]
