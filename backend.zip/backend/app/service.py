import asyncio
from datetime import datetime
from typing import Optional
from uuid import uuid4
from zoneinfo import ZoneInfo

import httpx

from .config import Settings
from .demo import demo_offers
from .models import Offer, SearchRequest, SearchResponse
from .platforms import DouyinAdapter, JdAdapter, PddAdapter, TaobaoAdapter
from .platforms.base import PlatformAdapter
from .ranking import rank_offers
from .token_store import TokenStore


class ComparisonService:
    def __init__(
        self,
        settings: Settings,
        client: Optional[httpx.AsyncClient] = None,
        token_store: Optional[TokenStore] = None,
    ):
        self.settings = settings
        self.client = client or httpx.AsyncClient(timeout=httpx.Timeout(15.0))
        self._owns_client = client is None
        self.token_store = token_store

    def configured_platforms(self) -> list[str]:
        result = []
        if self.settings.taobao_enabled:
            result.append("TAOBAO")
        if self.settings.jd_enabled:
            result.append("JD")
        if self.settings.pdd_enabled:
            result.append("PDD")
        if self.settings.douyin_enabled:
            result.append("DOUYIN")
        return result

    def _token(self, client_session_id: Optional[str], platform: str) -> str:
        if not client_session_id or self.token_store is None:
            return ""
        from .models import Platform

        return self.token_store.get_access_token(client_session_id, Platform(platform)) or ""

    def _adapters(self, client_session_id: Optional[str]) -> list[PlatformAdapter]:
        adapters: list[PlatformAdapter] = []
        if self.settings.taobao_enabled:
            adapters.append(TaobaoAdapter(
                self.client,
                self.settings,
                self._token(client_session_id, "TAOBAO"),
            ))
        jd_token = self._token(client_session_id, "JD")
        if self.settings.jd_enabled:
            adapters.append(JdAdapter(
                self.client,
                self.settings,
                jd_token,
            ))
        if self.settings.pdd_enabled:
            adapters.append(PddAdapter(self.client, self.settings))
        douyin_token = self._token(client_session_id, "DOUYIN") or self.settings.douyin_access_token
        if self.settings.douyin_app_key and self.settings.douyin_app_secret and douyin_token:
            adapters.append(DouyinAdapter(self.client, self.settings, douyin_token))
        return adapters

    async def search(self, request: SearchRequest, recognized_keyword: Optional[str] = None) -> SearchResponse:
        adapters = self._adapters(request.clientSessionId)
        platform_errors: list[str] = []
        offers: list[Offer] = []

        if adapters:
            results = await asyncio.gather(
                *(adapter.search(request.keyword, request.page, request.pageSize) for adapter in adapters),
                return_exceptions=True,
            )
            for adapter, result in zip(adapters, results):
                if isinstance(result, Exception):
                    platform_errors.append(f"{adapter.name}: {result}")
                else:
                    offers.extend(result)

        mode = "live"
        if not adapters and self.settings.allow_demo_fallback:
            offers = demo_offers(request.keyword)
            mode = "demo"
        elif not offers and len(platform_errors) == len(adapters) and self.settings.allow_demo_fallback:
            offers = demo_offers(request.keyword)
            mode = "demo_after_error"

        ranked = rank_offers(offers, request.sort)
        return SearchResponse(
            requestId=f"cmp_{uuid4().hex[:12]}",
            keyword=request.keyword,
            recognizedKeyword=recognized_keyword,
            priceUpdatedAt=datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds"),
            mode=mode,
            platformErrors=platform_errors,
            offers=ranked,
        )

    async def close(self) -> None:
        if self._owns_client:
            await self.client.aclose()
