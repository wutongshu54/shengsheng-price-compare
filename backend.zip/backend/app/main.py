from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import RedirectResponse

from .config import Settings
from .models import (
    AuthStartRequest,
    AuthStartResponse,
    AuthStatusResponse,
    Platform,
    RecognitionResponse,
    SearchRequest,
    SearchResponse,
)
from .oauth import OAuthService
from .service import ComparisonService
from .token_store import TokenStore
from .vision import recognize_image


settings = Settings()
http_client = httpx.AsyncClient(timeout=httpx.Timeout(20.0))
token_store = TokenStore(settings.token_database_path, settings.token_encryption_key)
comparison_service = ComparisonService(settings, client=http_client, token_store=token_store)
oauth_service = OAuthService(settings, http_client, token_store)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    await http_client.aclose()


app = FastAPI(
    title="省省比价 API",
    version="0.1.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict:
    return {
        "status": "ok",
        "configuredPlatforms": comparison_service.configured_platforms(),
        "demoFallback": settings.allow_demo_fallback,
        "visionConfigured": bool(settings.vision_api_url),
    }


@app.post("/api/v1/compare/search", response_model=SearchResponse)
async def compare_search(request: SearchRequest) -> SearchResponse:
    return await comparison_service.search(request)


@app.post("/api/v1/auth/start/{platform}", response_model=AuthStartResponse)
async def start_authorization(platform: Platform, request: AuthStartRequest) -> AuthStartResponse:
    try:
        return oauth_service.start(platform, request.clientSessionId)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/v1/auth/status", response_model=AuthStatusResponse)
async def authorization_status(clientSessionId: str = Query(min_length=8, max_length=128)) -> AuthStatusResponse:
    return oauth_service.status(clientSessionId)


@app.delete("/api/v1/auth/{platform}", status_code=204)
async def revoke_authorization(
    platform: Platform,
    clientSessionId: str = Query(min_length=8, max_length=128),
) -> None:
    oauth_service.revoke(clientSessionId, platform)


@app.get("/api/v1/auth/callback/{platform}")
async def authorization_callback(platform: Platform, state: str, code: str) -> RedirectResponse:
    try:
        app_url = await oauth_service.complete(platform, state, code)
        return RedirectResponse(app_url, status_code=302)
    except (httpx.HTTPError, RuntimeError, ValueError) as exc:
        from urllib.parse import urlencode

        query = urlencode({"platform": platform.value, "success": "false", "message": str(exc)})
        return RedirectResponse(f"{settings.app_return_url}?{query}", status_code=302)


@app.post("/api/v1/recognize-image", response_model=RecognitionResponse)
async def image_recognition(image: UploadFile = File(...)) -> RecognitionResponse:
    data = await image.read()
    if not data:
        raise HTTPException(status_code=400, detail="图片为空")
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="图片不能超过 10MB")
    try:
        return await recognize_image(
            image=data,
            filename=image.filename or "upload.jpg",
            content_type=image.content_type,
            settings=settings,
            client=http_client,
        )
    except (httpx.HTTPError, KeyError, ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/api/v1/compare/image-search", response_model=SearchResponse)
async def image_search(image: UploadFile = File(...)) -> SearchResponse:
    recognition = await image_recognition(image)
    request = SearchRequest(keyword=recognition.keyword)
    return await comparison_service.search(request, recognized_keyword=recognition.keyword)
