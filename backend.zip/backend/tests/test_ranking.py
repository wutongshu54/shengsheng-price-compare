from app.models import Offer, Platform, ShopType, SortOption
from app.ranking import rank_offers


def make_offer(identifier: str, price: float, platform: Platform = Platform.JD) -> Offer:
    return Offer(
        id=identifier,
        platform=platform,
        title=identifier,
        price=price,
        originalPrice=price,
        finalPrice=price,
        rating=4.8,
        reviewCount=100,
        sales=100,
        shopType=ShopType.OFFICIAL,
        matchConfidence=0.9,
    )


def test_recommendations_require_three_samples_per_platform() -> None:
    ranked = rank_offers(
        [make_offer("jd-1", 20), make_offer("jd-2", 30)],
        SortOption.recommended,
    )

    assert not any(offer.lowestPrice for offer in ranked)
    assert not any(offer.bestValue for offer in ranked)


def test_recommendations_mark_three_per_platform() -> None:
    offers = [
        make_offer("jd-1", 20),
        make_offer("jd-2", 30),
        make_offer("jd-3", 40),
        make_offer("jd-4", 200),
        make_offer("tb-1", 25, Platform.TAOBAO),
        make_offer("tb-2", 35, Platform.TAOBAO),
        make_offer("tb-3", 45, Platform.TAOBAO),
        make_offer("tb-4", 250, Platform.TAOBAO),
    ]

    ranked = rank_offers(offers, SortOption.recommended)

    for platform in (Platform.JD, Platform.TAOBAO):
        platform_offers = [offer for offer in ranked if offer.platform == platform]
        assert sum(offer.lowestPrice for offer in platform_offers) == 3
        assert sum(offer.bestValue for offer in platform_offers) == 3
        assert not next(offer for offer in platform_offers if offer.id.endswith("4")).lowestPrice
