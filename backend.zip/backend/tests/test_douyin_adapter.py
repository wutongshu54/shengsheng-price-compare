import asyncio
import json
from urllib.parse import parse_qs

import httpx

from app.config import Settings
from app.models import Platform
from app.platforms.douyin import DouyinAdapter


def test_search_uses_official_request_shape_and_maps_prices() -> None:
    captured_query: dict[str, list[str]] = {}
    captured_body: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured_query.update(parse_qs(request.url.query.decode("utf-8")))
        captured_body.update(json.loads(request.content.decode("utf-8")))
        return httpx.Response(
            200,
            json={
                "code": 10000,
                "msg": "success",
                "data": {
                    "products": [
                        {
                            "product_id": "3400312511185213726",
                            "title": "测试运动鞋",
                            "price": 19900,
                            "coupon_price": 16900,
                            "sales": 1234,
                            "shop_name": "测试旗舰店",
                            "detail_url": "https://haohuo.jinritemai.com/item/1",
                        }
                    ]
                },
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = DouyinAdapter(
                client,
                Settings(
                    douyin_app_key="app-key",
                    douyin_app_secret="app-secret",
                    douyin_access_token="access-token",
                ),
            )
            offers = await adapter.search("运动鞋", page=2, page_size=100)
            assert len(offers) == 1
            assert offers[0].platform == Platform.DOUYIN
            assert offers[0].price == 199
            assert offers[0].coupon == 30
            assert offers[0].finalPrice == 169

    asyncio.run(run_search())

    assert captured_query["method"] == ["buyin.kolMaterialsProductsSearch"]
    assert captured_query["sign_method"] == ["hmac-sha256"]
    assert captured_body == {
        "page": 2,
        "page_size": 20,
        "search_type": 0,
        "share_status": 1,
        "sort_type": 0,
        "title": "运动鞋",
    }
