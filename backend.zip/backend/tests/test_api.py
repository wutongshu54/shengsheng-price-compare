from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_health_reports_demo_mode() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_demo_search_returns_four_platforms() -> None:
    response = client.post(
        "/api/v1/compare/search",
        json={"keyword": "白色运动鞋", "sort": "price_lowest"},
    )
    assert response.status_code == 200
    payload = response.json()
    assert payload["mode"] == "demo"
    assert len(payload["offers"]) == 4
    assert payload["offers"][0]["platform"] == "PDD"
    assert payload["offers"][0]["lowestPrice"] is False


def test_unknown_demo_keyword_returns_empty() -> None:
    response = client.post("/api/v1/compare/search", json={"keyword": "咖啡机"})
    assert response.status_code == 200
    assert response.json()["offers"] == []


def test_demo_image_recognition() -> None:
    response = client.post(
        "/api/v1/recognize-image",
        files={"image": ("shoe.jpg", b"fake-image", "image/jpeg")},
    )
    assert response.status_code == 200
    assert response.json()["keyword"] == "白色运动鞋"


def test_demo_authorization_flow() -> None:
    session_id = "android-test-session"
    start = client.post(
        "/api/v1/auth/start/TAOBAO",
        json={"clientSessionId": session_id},
    )
    assert start.status_code == 200
    assert start.json()["demo"] is True
    assert start.json()["authorizationUrl"].startswith("pricecompare://oauth-complete")

    status = client.get("/api/v1/auth/status", params={"clientSessionId": session_id})
    taobao = next(item for item in status.json()["platforms"] if item["platform"] == "TAOBAO")
    assert taobao["authorized"] is True

    revoke = client.delete(f"/api/v1/auth/TAOBAO?clientSessionId={session_id}")
    assert revoke.status_code == 204


def test_douyin_requires_server_side_alliance_credentials() -> None:
    response = client.post(
        "/api/v1/auth/start/DOUYIN",
        json={"clientSessionId": "android-test-session"},
    )

    assert response.status_code == 503
    assert "企业主体" in response.json()["detail"]
