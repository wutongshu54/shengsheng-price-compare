import asyncio
from urllib.parse import parse_qs

import httpx

from app.config import Settings
from app.platforms.pdd import PddAdapter


def test_pdd_is_enabled_without_access_token() -> None:
    settings = Settings(pdd_client_id="client-id", pdd_client_secret="client-secret")

    assert settings.pdd_enabled is True


def test_pdd_search_uses_non_oauth_goods_api() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        captured.update({key: value[0] for key, value in form.items()})
        return httpx.Response(
            200,
            json={
                "goods_search_response": {
                    "goods_list": [
                        {
                            "goods_id": 123,
                            "goods_name": "65W 氮化镓充电器",
                            "min_group_price": 3990,
                            "coupon_discount": 500,
                        }
                    ]
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = PddAdapter(
                client,
                Settings(pdd_client_id="client-id", pdd_client_secret="client-secret"),
            )
            offers = await adapter.search("充电器", page=1, page_size=30)

        assert len(offers) == 1
        assert offers[0].finalPrice == 34.9

    asyncio.run(run_search())

    assert captured["type"] == "pdd.ddk.goods.search"
    assert captured["client_id"] == "client-id"
    assert "access_token" not in captured
