import asyncio
import json
from urllib.parse import parse_qs

import httpx
import pytest

from app.config import Settings
from app.platforms.jd import JdAdapter


def test_search_uses_required_scene_and_caps_page_size() -> None:
    captured_form: dict[str, list[str]] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured_form.update(parse_qs(request.content.decode("utf-8")))
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_responce": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": []})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert await adapter.search("手机", page=2, page_size=100) == []

    asyncio.run(run_search())

    request_body = json.loads(captured_form["360buy_param_json"][0])
    assert request_body == {
        "goodsReqDTO": {
            "keyword": "手机",
            "pageIndex": 2,
            "pageSize": 30,
            "sceneId": 1,
        }
    }


def test_search_reports_top_level_error_response() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "error_response": {
                    "code": "403",
                    "zh_desc": "应用无接口权限",
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            with pytest.raises(RuntimeError, match="应用无接口权限"):
                await adapter.search("手机", page=1, page_size=10)

    asyncio.run(run_search())


def test_search_accepts_corrected_response_key() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_response": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": []})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert await adapter.search("手机", page=1, page_size=10) == []

    asyncio.run(run_search())
