import asyncio
import json
from urllib.parse import parse_qs

import httpx
import pytest

from app.config import Settings
from app.platforms.jd import JdAdapter


def test_search_uses_required_scene_and_caps_page_size() -> None:
    captured_form: dict[str, list[str]] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured_form.update(parse_qs(request.content.decode("utf-8")))
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_responce": {
                    "queryResult": json.dumps(
                        {
                            "code": 200,
                            "message": "success",
                            "data": [
                                {"skuId": str(index), "skuName": f"智能手机 {index}", "priceInfo": {"price": 999}}
                                for index in range(3)
                            ],
                        }
                    )
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert len(await adapter.search("手机", page=2, page_size=100)) == 3

    asyncio.run(run_search())

    request_body = json.loads(captured_form["360buy_param_json"][0])
    assert "access_token" not in captured_form
    assert request_body == {
        "goodsReqDTO": {
            "keyword": "手机",
            "pageIndex": 2,
            "pageSize": 30,
            "sceneId": 1,
        }
    }


def test_search_reports_top_level_error_response() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "error_response": {
                    "code": "403",
                    "zh_desc": "应用无接口权限",
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            with pytest.raises(RuntimeError, match="应用无接口权限"):
                await adapter.search("手机", page=1, page_size=10)

    asyncio.run(run_search())


def test_search_accepts_corrected_response_key() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_response": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": []})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert await adapter.search("相机", page=1, page_size=10) == []

    asyncio.run(run_search())


def test_search_falls_back_to_material_pools_without_keyword_permission() -> None:
    methods: list[str] = []
    material_pages: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        method = form["method"][0]
        methods.append(method)
        if method == "jd.union.open.goods.query":
            return httpx.Response(
                200,
                json={"error_response": {"code": "403", "zh_desc": "无访问权限"}},
            )
        request_body = json.loads(form["360buy_param_json"][0])
        material_pages.append(request_body["goodsReq"]["pageIndex"])
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_material_query_responce": {
                    "queryResult": json.dumps(
                        {
                            "code": 200,
                            "message": "success",
                            "data": [
                                {
                                    "itemId": "123",
                                    "skuName": "Apple 苹果手机",
                                    "priceInfo": {"price": 4999},
                                    "materialUrl": "item.jd.com/123.html",
                                },
                                {
                                    "skuId": "456",
                                    "skuName": "无线耳机",
                                    "priceInfo": {"price": 199},
                                },
                            ],
                        }
                    )
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            offers = await adapter.search("苹果手机", page=1, page_size=10)
            assert [offer.id for offer in offers] == ["123"]
            assert offers[0].productUrl == "https://item.jd.com/123.html"

    asyncio.run(run_search())

    assert methods[0] == "jd.union.open.goods.query"
    assert methods.count("jd.union.open.goods.material.query") == (
        len(JdAdapter.material_elite_ids) * JdAdapter.material_page_count
    )
    assert set(material_pages) == {1, 2, 3}


def test_search_expands_charger_aliases_until_three_matches() -> None:
    queried_keywords: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        request_body = json.loads(form["360buy_param_json"][0])
        keyword = request_body["goodsReqDTO"]["keyword"]
        queried_keywords.append(keyword)
        if keyword == "充电头":
            data = [
                {
                    "skuId": "exact",
                    "skuName": "20W 手机充电头",
                    "categoryInfo": {"cid3Name": "手机配件"},
                    "priceInfo": {"price": 39},
                }
            ]
        elif keyword == "充电器":
            data = [
                {
                    "skuId": "alias-1",
                    "skuName": "30W 快充充电器",
                    "categoryInfo": {"cid3Name": "数码配件"},
                    "priceInfo": {"price": 49},
                },
                {
                    "skuId": "alias-2",
                    "skuName": "65W 氮化镓充电器",
                    "categoryInfo": {"cid3Name": "电源适配器"},
                    "priceInfo": {"price": 79},
                },
            ]
        else:
            data = []
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_responce": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": data})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            offers = await adapter.search("充电头", page=1, page_size=10)

        assert len(offers) == 3
        assert [offer.id for offer in offers] == ["exact", "alias-1", "alias-2"]

    asyncio.run(run_search())

    assert queried_keywords == ["充电头", "充电器"]


def test_search_checks_additional_keyword_pages_until_three_matches() -> None:
    queried_pages: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        request_body = json.loads(form["360buy_param_json"][0])
        keyword = request_body["goodsReqDTO"]["keyword"]
        page_index = request_body["goodsReqDTO"]["pageIndex"]
        if keyword == "充电器":
            queried_pages.append(page_index)
        if keyword == "充电器" and page_index == 1:
            data = [
                {
                    "skuId": "page-1",
                    "skuName": "20W 手机充电器",
                    "categoryInfo": {"cid3Name": "手机配件"},
                    "priceInfo": {"price": 39},
                }
            ]
        elif keyword == "充电器" and page_index == 2:
            data = [
                {
                    "skuId": "page-2-a",
                    "skuName": "30W USB-C 充电器",
                    "categoryInfo": {"cid3Name": "数码配件"},
                    "priceInfo": {"price": 49},
                },
                {
                    "skuId": "page-2-b",
                    "skuName": "65W 氮化镓充电器",
                    "categoryInfo": {"cid3Name": "电源适配器"},
                    "priceInfo": {"price": 79},
                },
            ]
        else:
            data = []
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_responce": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": data})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            offers = await adapter.search("充电器", page=1, page_size=10)

        assert [offer.id for offer in offers] == ["page-1", "page-2-a", "page-2-b"]

    asyncio.run(run_search())

    assert queried_pages == [1, 2]


def test_material_fallback_does_not_match_individual_chinese_characters() -> None:
    assert not JdAdapter._matches_keyword(
        {"skuName": "手动挤压牙膏器", "brandName": "无品牌"},
        "手机",
    )


def test_material_fallback_rejects_accessory_mentioned_as_a_gift() -> None:
    assert not JdAdapter._matches_keyword(
        {
            "skuName": "飞利浦电动剃须刀 豪华套餐含充电头",
            "categoryInfo": {"cid3Name": "二手剃须刀"},
        },
        "充电头",
    )


def test_material_fallback_accepts_charger_alias() -> None:
    assert JdAdapter._matches_keyword(
        {
            "skuName": "Apple 20W Type-C 快充充电器",
            "categoryInfo": {"cid3Name": "直插充电器"},
        },
        "充电头",
    )


def test_charger_alias_accepts_digital_accessory_category() -> None:
    assert JdAdapter._matches_keyword(
        {
            "skuName": "30W USB-C 快充充电器",
            "categoryInfo": {"cid3Name": "数码配件"},
        },
        "快充头",
    )


def test_charger_alias_accepts_clear_title_with_unrecognized_category() -> None:
    assert JdAdapter._matches_keyword(
        {
            "skuName": "45W USB-C 手机快充充电器",
            "categoryInfo": {"cid3Name": "其他3C配件"},
        },
        "充电头",
    )


def test_charger_alias_rejects_power_bank_bundle() -> None:
    assert not JdAdapter._matches_keyword(
        {
            "skuName": "大容量充电宝附赠快充头",
            "categoryInfo": {"cid3Name": "移动电源"},
        },
        "充电头",
    )


def test_material_candidates_are_filtered_and_sorted_by_effective_price() -> None:
    items = [
        {
            "skuId": "expensive",
            "skuName": "Apple 20W Type-C 快充充电器",
            "categoryInfo": {"cid3Name": "直插充电器"},
            "priceInfo": {"price": 149},
        },
        {
            "skuId": "wrong-category",
            "skuName": "飞利浦剃须刀赠充电头",
            "categoryInfo": {"cid3Name": "电动剃须刀"},
            "priceInfo": {"price": 29},
        },
        {
            "skuId": "cheap",
            "skuName": "氮化镓 20W 手机快充头",
            "categoryInfo": {"cid3Name": "直插充电器"},
            "priceInfo": {"price": 39},
        },
    ]

    matched = JdAdapter._filter_and_sort_items(items, "充电头", page_size=30)

    assert [item["skuId"] for item in matched] == ["cheap", "expensive"]
    assert matched[0]["_matchConfidence"] > JdAdapter.minimum_match_score


def test_map_item_uses_only_coupon_that_meets_quota() -> None:
    item = {
        "skuId": "charger",
        "skuName": "65W 氮化镓充电器",
        "priceInfo": {"price": 100},
        "couponInfo": {
            "couponList": [
                {"discount": 50, "quota": 200, "link": "invalid.example"},
                {"discount": 10, "quota": 99, "link": "valid.example"},
            ]
        },
    }

    offer = JdAdapter._map_item(JdAdapter.__new__(JdAdapter), item)

    assert offer.price == 100
    assert offer.coupon == 10
    assert offer.finalPrice == 90
    assert offer.productUrl == "https://valid.example"


def test_map_item_prefers_official_lowest_coupon_price() -> None:
    item = {
        "skuId": "charger",
        "skuName": "65W 氮化镓充电器",
        "priceInfo": {"price": 100, "lowestCouponPrice": 79},
        "couponInfo": {"couponList": [{"discount": 10, "quota": 99}]},
    }

    offer = JdAdapter._map_item(JdAdapter.__new__(JdAdapter), item)

    assert offer.coupon == 21
    assert offer.finalPrice == 79
