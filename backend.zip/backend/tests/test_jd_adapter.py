import asyncio
import json
from urllib.parse import parse_qs

import httpx
import pytest

from app.config import Settings
from app.platforms.jd import JdAdapter


def test_search_uses_required_scene_and_caps_page_size() -> None:
    captured_form: dict[str, list[str]] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured_form.update(parse_qs(request.content.decode("utf-8")))
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_responce": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": []})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert await adapter.search("手机", page=2, page_size=100) == []

    asyncio.run(run_search())

    request_body = json.loads(captured_form["360buy_param_json"][0])
    assert "access_token" not in captured_form
    assert request_body == {
        "goodsReqDTO": {
            "keyword": "手机",
            "pageIndex": 2,
            "pageSize": 30,
            "sceneId": 1,
        }
    }


def test_search_reports_top_level_error_response() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "error_response": {
                    "code": "403",
                    "zh_desc": "应用无接口权限",
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            with pytest.raises(RuntimeError, match="应用无接口权限"):
                await adapter.search("手机", page=1, page_size=10)

    asyncio.run(run_search())


def test_search_accepts_corrected_response_key() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_query_response": {
                    "queryResult": json.dumps({"code": 200, "message": "success", "data": []})
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            assert await adapter.search("手机", page=1, page_size=10) == []

    asyncio.run(run_search())


def test_search_falls_back_to_material_pools_without_keyword_permission() -> None:
    methods: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        method = form["method"][0]
        methods.append(method)
        if method == "jd.union.open.goods.query":
            return httpx.Response(
                200,
                json={"error_response": {"code": "403", "zh_desc": "无访问权限"}},
            )
        return httpx.Response(
            200,
            json={
                "jd_union_open_goods_material_query_responce": {
                    "queryResult": json.dumps(
                        {
                            "code": 200,
                            "message": "success",
                            "data": [
                                {
                                    "itemId": "123",
                                    "skuName": "Apple 苹果手机",
                                    "priceInfo": {"price": 4999},
                                    "materialUrl": "item.jd.com/123.html",
                                },
                                {
                                    "skuId": "456",
                                    "skuName": "无线耳机",
                                    "priceInfo": {"price": 199},
                                },
                            ],
                        }
                    )
                }
            },
        )

    async def run_search() -> None:
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            adapter = JdAdapter(
                client,
                Settings(jd_app_key="app-key", jd_app_secret="app-secret"),
            )
            offers = await adapter.search("苹果手机", page=1, page_size=10)
            assert [offer.id for offer in offers] == ["123"]
            assert offers[0].productUrl == "https://item.jd.com/123.html"

    asyncio.run(run_search())

    assert methods[0] == "jd.union.open.goods.query"
    assert methods.count("jd.union.open.goods.material.query") == len(JdAdapter.material_elite_ids)


def test_material_fallback_does_not_match_individual_chinese_characters() -> None:
    assert not JdAdapter._matches_keyword(
        {"skuName": "手动挤压牙膏器", "brandName": "无品牌"},
        "手机",
    )


def test_material_fallback_rejects_accessory_mentioned_as_a_gift() -> None:
    assert not JdAdapter._matches_keyword(
        {
            "skuName": "飞利浦电动剃须刀 豪华套餐含充电头",
            "categoryInfo": {"cid3Name": "二手剃须刀"},
        },
        "充电头",
    )


def test_material_fallback_accepts_charger_alias() -> None:
    assert JdAdapter._matches_keyword(
        {
            "skuName": "Apple 20W Type-C 快充充电器",
            "categoryInfo": {"cid3Name": "直插充电器"},
        },
        "充电头",
    )
