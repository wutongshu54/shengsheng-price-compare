from app.signing import md5_platform_sign


def test_signing_is_sorted_and_ignores_existing_sign() -> None:
    first = md5_platform_sign({"b": 2, "a": 1, "sign": "old"}, "secret")
    second = md5_platform_sign({"a": 1, "b": 2}, "secret")
    assert first == second
    assert first == first.upper()
