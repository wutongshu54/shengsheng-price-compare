from app.signing import douyin_hmac_sha256_sign, md5_platform_sign


def test_signing_is_sorted_and_ignores_existing_sign() -> None:
    first = md5_platform_sign({"b": 2, "a": 1, "sign": "old"}, "secret")
    second = md5_platform_sign({"a": 1, "b": 2}, "secret")
    assert first == second
    assert first == first.upper()


def test_douyin_hmac_sha256_sign_uses_official_parameter_order() -> None:
    result = douyin_hmac_sha256_sign(
        app_key="app-key",
        app_secret="app-secret",
        method="buyin.kolMaterialsProductsSearch",
        param_json='{"page":1,"title":"运动鞋"}',
        timestamp="1787790000",
    )

    assert result == "8ea98686ad0e04da33b895131663e7001a621c8bab851a2c6e653bea74655bcb"
