# 省省比价后端

后端统一封装淘宝联盟、京东联盟和多多进宝商品查询，避免在 Android APK 中暴露平台密钥。

## 启动

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
set -a && source .env && set +a
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

依赖安装完成后，也可以直接运行：

```bash
./start.sh
```

打开 `http://127.0.0.1:8000/docs` 可以查看接口并测试。

未配置平台密钥时，`ALLOW_DEMO_FALLBACK=true` 会返回演示数据。配置任一平台的完整环境变量后，该平台适配器自动启用。

## OAuth 授权

正式接入时，在 `.env` 中配置公网 HTTPS 回调地址和令牌加密密钥：

```text
PUBLIC_BASE_URL=https://你的域名
APP_RETURN_URL=pricecompare://oauth-complete
TOKEN_ENCRYPTION_KEY=生成的Fernet密钥
```

生成加密密钥：

```bash
.venv/bin/python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

平台控制台中的回调地址分别填写：

```text
https://你的域名/api/v1/auth/callback/TAOBAO
https://你的域名/api/v1/auth/callback/JD
https://你的域名/api/v1/auth/callback/PDD
```

`JD_AUTH_URL`、`JD_TOKEN_URL` 和 `PDD_AUTH_URL` 必须使用账号控制台当前提供的地址。访问令牌加密保存在 `data/tokens.db`，不会返回给 Android。

## Android 地址

Android 模拟器访问电脑本机使用：

```text
http://10.0.2.2:8000
```

真机需要改成电脑在同一局域网内的 IP，例如：

```bash
./gradlew assembleDebug -PBACKEND_BASE_URL=http://192.168.1.10:8000
```

## 正式部署

- Render 可直接读取项目根目录的 `render.yaml` 创建 Web Service。
- 默认服务地址为 `https://shengsheng-price-compare-api.onrender.com`，部署后请访问 `/health` 验证。
- 使用 HTTPS，关闭全局明文 HTTP。
- 将密钥放在云平台 Secret Manager 或服务器环境变量中。
- 根据开放平台实际审批权限校对 API 名称、参数和返回字段。
- 增加限流、请求日志、缓存、超时、重试与价格更新时间。
- 平台接口返回结构可能随权限和版本变化，适配器采用了容错读取，但上线前必须使用真实账号联调。
