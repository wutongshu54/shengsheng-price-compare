# 省省比价后端

FastAPI 聚合服务，负责平台签名、商品查询、结果归一化、图片识别和演示降级。

## 本地运行

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## 测试

```bash
pytest -q
```

当前测试基线：`16 passed`。

## 主要环境变量

- 淘宝：`TAOBAO_APP_KEY`、`TAOBAO_APP_SECRET`、`TAOBAO_ADZONE_ID`
- 京东：`JD_APP_KEY`、`JD_APP_SECRET`、`JD_ACCESS_TOKEN`、`JD_UNION_ID`
- 拼多多：`PDD_CLIENT_ID`、`PDD_CLIENT_SECRET`、`PDD_ACCESS_TOKEN`、`PDD_PID`
- 抖音：`DOUYIN_APP_KEY`、`DOUYIN_APP_SECRET`、`DOUYIN_ACCESS_TOKEN`
- 图片识别：`VISION_API_URL`、`VISION_API_TOKEN`
- 服务：`ALLOW_DEMO_FALLBACK`、`PUBLIC_BASE_URL`、`TOKEN_DATABASE_PATH`、`TOKEN_ENCRYPTION_KEY`

真实值只允许写入本地 `.env` 或 Render 环境变量，不得写入仓库。

## 部署

- Render 配置位于项目根目录 `render.yaml`。
- 线上服务：https://shengsheng-price-compare-api.onrender.com
- 部署仓库：https://github.com/wutongshu54/shengsheng-price-compare
- 当前线上提交：`fb0766a`

平台接口权限和返回结构可能变化，修改适配器后必须运行测试并使用线上关键词验证。

