# 省省比价后端

后端统一封装淘宝联盟、京东联盟、多多进宝和抖音精选联盟商品查询，避免在 Android APK 中暴露平台密钥。

## 启动

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
set -a && source .env && set +a
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

依赖安装完成后，也可以直接运行：

```bash
./start.sh
```

打开 `http://127.0.0.1:8000/docs` 可以查看接口并测试。

未配置平台密钥时，`ALLOW_DEMO_FALLBACK=true` 会返回演示数据。配置任一平台的完整环境变量后，该平台适配器自动启用。

京东真实查询至少需要 `JD_APP_KEY`、`JD_APP_SECRET` 和京东联盟“我的 API”页面领取的 `JD_ACCESS_TOKEN`。只有 AppKey 和 Secret 时，后端不会再误判为已完成京东接入。

抖音使用精选联盟 `buyin.kolMaterialsProductsSearch` 接口。正式启用需要企业主体完成开放平台入驻、应用上架，并取得达人或抖客授权令牌；普通 App 用户无需登录抖音。服务端配置：

```text
DOUYIN_APP_KEY=
DOUYIN_APP_SECRET=
DOUYIN_ACCESS_TOKEN=
DOUYIN_GATEWAY=https://openapi-fxg.jinritemai.com
```

## OAuth 授权

正式接入时，在 `.env` 中配置公网 HTTPS 回调地址和令牌加密密钥：

```text
PUBLIC_BASE_URL=https://你的域名
APP_RETURN_URL=pricecompare://oauth-complete
TOKEN_ENCRYPTION_KEY=生成的Fernet密钥
```

生成加密密钥：

```bash
.venv/bin/python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

平台控制台中的回调地址分别填写：

```text
https://你的域名/api/v1/auth/callback/TAOBAO
https://你的域名/api/v1/auth/callback/JD
https://你的域名/api/v1/auth/callback/PDD
```

抖音精选联盟授权码由已上架服务的“使用地址”接收，不复用上述面向终端用户的一键 OAuth 流程。取得的 `access_token` 仅保存在后端环境变量或密钥管理服务中。

`JD_AUTH_URL` 和 `JD_TOKEN_URL` 必须使用账号控制台当前提供的地址。多多进宝推手授权默认使用 `https://jinbao.pinduoduo.com/open.html`。访问令牌加密保存在 `data/tokens.db`，不会返回给 Android。

多多进宝真实商品查询需要在服务端配置 `PDD_CLIENT_ID` 和 `PDD_CLIENT_SECRET`，然后由用户在 App 内完成一次官方授权，后端会用授权码换取并加密保存 `access_token`。`PDD_PID` 不是商品搜索的必填项，但生成推广链接时需要配置；也可以在授权后通过推广位接口创建。

## Android 地址

Android 模拟器访问电脑本机使用：

```text
http://10.0.2.2:8000
```

真机需要改成电脑在同一局域网内的 IP，例如：

```bash
./gradlew assembleDebug -PBACKEND_BASE_URL=http://192.168.1.10:8000
```

## 正式部署

- Render 可直接读取项目根目录的 `render.yaml` 创建 Web Service。
- 默认服务地址为 `https://shengsheng-price-compare-api.onrender.com`，部署后请访问 `/health` 验证。
- 使用 HTTPS，关闭全局明文 HTTP。
- 将密钥放在云平台 Secret Manager 或服务器环境变量中。
- 根据开放平台实际审批权限校对 API 名称、参数和返回字段。
- 增加限流、请求日志、缓存、超时、重试与价格更新时间。
- 平台接口返回结构可能随权限和版本变化，适配器采用了容错读取，但上线前必须使用真实账号联调。
